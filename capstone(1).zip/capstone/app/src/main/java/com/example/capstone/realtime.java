package com.example.capstone;

public class realtime {
    private String 보행자;
    private String 차량;
    private String 주기;

    public realtime() {
    }

    public realtime(String 보행자, String 차량, String 주기) {
        this.보행자 = 보행자;
        this.차량 = 차량;
        this.주기 = 주기;
    }

    public String get보행자() {
        return 보행자;
    }

    public void set보행자(String 보행자) {
        this.보행자 = 보행자;
    }

    public String get차량() {
        return 차량;
    }

    public void set차량(String 차량) {
        this.차량 = 차량;
    }

    public String get주기() {
        return 주기;
    }

    public void set주기(String 주기) {
        this.주기 = 주기;
    }
}
